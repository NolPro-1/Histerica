import json
import re
from pathlib import Path

from flask import Flask, jsonify, render_template, request
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
USERS_PATH = BASE_DIR / "users.json"
DATA_PATH = BASE_DIR / "data.json"
ADMIN_PASSWORD = "qwerty"
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png"}
app = Flask(
    __name__,
    template_folder=str(BASE_DIR / "templates"),
    static_folder=str(BASE_DIR / "static"),
)


@app.route("/")
def index():
    return render_template("index.html")


def load_users():
    if not USERS_PATH.exists():
        return []
    with USERS_PATH.open("r", encoding="utf-8") as file:
        return json.load(file)


def save_users(users):
    with USERS_PATH.open("w", encoding="utf-8") as file:
        json.dump(users, file, ensure_ascii=False, indent=2)


def load_data():
    if not DATA_PATH.exists():
        return {"museums": [], "artifacts": []}
    with DATA_PATH.open("r", encoding="utf-8") as file:
        return json.load(file)


def save_data(data):
    with DATA_PATH.open("w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=2)


def allowed_file(filename):
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS


def save_uploaded_image(file_obj, folder, filename):
    target_dir = BASE_DIR / "static" / "source" / folder
    target_dir.mkdir(parents=True, exist_ok=True)
    file_obj.save(target_dir / filename)
    return f"source/{folder}/{filename}"


def dms_to_decimal(degrees, minutes, seconds, direction):
    value = float(degrees)
    value += float(minutes or 0) / 60
    value += float((seconds or "0").replace(",", ".")) / 3600
    sign = -1 if direction in {"S", "Ю", "W", "З"} else 1
    return sign * value


def find_museum(data, museum_id):
    return next((museum for museum in data.get("museums", []) if museum.get("id") == museum_id), None)


def parse_coordinates(raw_value):
    value = str(raw_value or "").strip()
    if not value:
        return None

    normalized = value.upper().replace("Ё", "Е")
    dms_pattern = re.compile(
        r"(\d{1,3})\s*[°º]\s*(\d{1,2})?\s*[\'′]?\s*(\d{1,2}(?:[.,]\d+)?)?\s*[\"″]?\s*([NSEWСЮВЗ])"
    )
    dms_matches = dms_pattern.findall(normalized)
    if len(dms_matches) >= 2:
        lat = dms_to_decimal(*dms_matches[0])
        lon = dms_to_decimal(*dms_matches[1])
        return round(lat, 7), round(lon, 7)

    numeric_values = []
    for chunk in re.findall(r"[-+]?\d+(?:[.,]\d+)?", value):
        try:
            numeric_values.append(float(chunk.replace(",", ".")))
        except ValueError:
            continue
    if len(numeric_values) >= 2:
        return round(numeric_values[0], 7), round(numeric_values[1], 7)
    return None


@app.route("/api/register", methods=["POST"])
def register():
    payload = request.get_json(silent=True) or {}
    nickname = str(payload.get("nickname", "")).strip()
    email = str(payload.get("email", "")).strip().lower()
    password = str(payload.get("password", "")).strip()

    if not nickname:
        return jsonify({"error": "Введите никнейм."}), 400
    if not email or "@" not in email:
        return jsonify({"error": "Проверьте корректность почты."}), 400
    if len(password) < 8 or not password.isalnum():
        return jsonify(
            {
                "error": "Пароль должен быть не меньше 8 символов и содержать только латинские буквы и цифры."
            }
        ), 400

    users = load_users()
    if any(user["nickname"].lower() == nickname.lower() for user in users):
        return jsonify({"error": "Никнейм уже занят."}), 400
    if any(user["email"].lower() == email for user in users):
        return jsonify({"error": "Аккаунт с такой почтой уже существует."}), 400

    masked_email = email
    if "@" in email:
        name, domain = email.split("@", 1)
        masked_name = name[:-5] + "*****" if len(name) > 5 else "*****"
        masked_email = f"{masked_name}@{domain}"
    user_profile = {
        "museums_completed": 0,
        "artifacts_found": 0,
        "rating": 0,
        "email_masked": masked_email,
        "two_factor_enabled": False,
    }
    users.append(
        {
            "nickname": nickname,
            "email": email,
            "password": password,
            "profile": user_profile,
            "inventory": {"skins": [], "items": [], "achievements": []},
        }
    )
    save_users(users)
    return jsonify(
        {
            "success": True,
            "profile": user_profile,
            "nickname": nickname,
            "inventory": {"skins": [], "items": [], "achievements": []},
        }
    )


@app.route("/api/login", methods=["POST"])
def login():
    payload = request.get_json(silent=True) or {}
    identity = str(payload.get("identity", "")).strip().lower()
    password = str(payload.get("password", "")).strip()

    users = load_users()
    user = next(
        (
            u
            for u in users
            if u["nickname"].lower() == identity or u["email"].lower() == identity
        ),
        None,
    )
    if not user:
        return jsonify({"error": "Пользователь не найден."}), 400
    if user["password"] != password:
        return jsonify({"error": "Неверный пароль."}), 400
    return jsonify(
        {
            "success": True,
            "nickname": user["nickname"],
            "profile": user.get("profile", {}),
            "inventory": user.get("inventory", {}),
        }
    )


@app.route("/api/admin/login", methods=["POST"])
def admin_login():
    payload = request.get_json(silent=True) or {}
    password = str(payload.get("password", "")).strip()
    if password != ADMIN_PASSWORD:
        return jsonify({"error": "Неверный пароль администратора."}), 400
    return jsonify({"success": True})


@app.route("/api/admin/data", methods=["GET"])
def admin_data():
    return jsonify(load_data())


@app.route("/api/museums", methods=["GET"])
def list_museums():
    data = load_data()
    return jsonify(data.get("museums", []))


@app.route("/api/admin/museums", methods=["POST"])
def admin_create_museum():
    name = str(request.form.get("name", "")).strip()
    address = str(request.form.get("address", "")).strip()
    city = str(request.form.get("city", "")).strip() or "Севастополь"
    description = str(request.form.get("description", "")).strip()
    coordinates = str(request.form.get("coordinates", "")).strip()
    parsed_coordinates = parse_coordinates(coordinates)
    photo = request.files.get("photo")
    location_map = request.files.get("location_map")

    if not name:
        return jsonify({"error": "Введите название музея."}), 400
    if not address:
        return jsonify({"error": "Введите адрес музея."}), 400
    if not city:
        return jsonify({"error": "Введите город музея."}), 400
    if coordinates and not parsed_coordinates:
        return jsonify({"error": "Введите координаты в формате: 44.6182, 33.5254 или 44°37′06″ с. ш. 33°31′27″ в. д."}), 400
    if not photo or not allowed_file(photo.filename):
        return jsonify({"error": "Загрузите изображение музея .jpg или .png."}), 400

    if location_map and location_map.filename and not allowed_file(location_map.filename):
        return jsonify({"error": "Карта локации должна быть .jpg или .png."}), 400

    data = load_data()
    museum_id = max((item.get("id", 0) for item in data.get("museums", [])), default=0) + 1

    photo_extension = Path(secure_filename(photo.filename)).suffix.lower()
    museum_image_path = save_uploaded_image(photo, "museum", f"{museum_id}{photo_extension}")

    map_image_path = f"source/maps/{museum_id}.png"
    if location_map and location_map.filename:
        map_extension = Path(secure_filename(location_map.filename)).suffix.lower()
        map_image_path = save_uploaded_image(location_map, "maps", f"{museum_id}{map_extension}")

    latitude = parsed_coordinates[0] if parsed_coordinates else None
    longitude = parsed_coordinates[1] if parsed_coordinates else None

    data["museums"].append(
        {
            "id": museum_id,
            "name": name,
            "description": description,
            "address": address,
            "city": city,
            "coordinates": coordinates,
            "latitude": latitude,
            "longitude": longitude,
            "map_image": map_image_path,
            "artifacts": [],
            "image": museum_image_path,
        }
    )
    save_data(data)
    return jsonify({"success": True, "museum": data["museums"][-1]})


@app.route("/api/admin/museums/<int:museum_id>", methods=["PUT"])
def admin_update_museum(museum_id):
    name = str(request.form.get("name", "")).strip()
    description = str(request.form.get("description", "")).strip()
    address = str(request.form.get("address", "")).strip()
    city = str(request.form.get("city", "")).strip() or "Севастополь"
    coordinates = str(request.form.get("coordinates", "")).strip()
    parsed_coordinates = parse_coordinates(coordinates) if coordinates else None
    photo = request.files.get("photo")
    location_map = request.files.get("location_map")

    if not name:
        return jsonify({"error": "Введите название музея."}), 400
    if not address:
        return jsonify({"error": "Введите адрес музея."}), 400
    if not city:
        return jsonify({"error": "Введите город музея."}), 400
    if coordinates and not parsed_coordinates:
        return jsonify({"error": "Некорректный формат координат."}), 400
    if photo and photo.filename and not allowed_file(photo.filename):
        return jsonify({"error": "Загрузите изображение музея .jpg или .png."}), 400
    if location_map and location_map.filename and not allowed_file(location_map.filename):
        return jsonify({"error": "Карта локации должна быть .jpg или .png."}), 400

    data = load_data()
    museum = find_museum(data, museum_id)
    if not museum:
        return jsonify({"error": "Музей не найден."}), 404

    museum["name"] = name
    museum["description"] = description
    museum["address"] = address
    museum["city"] = city
    museum["coordinates"] = coordinates
    museum["latitude"] = parsed_coordinates[0] if parsed_coordinates else None
    museum["longitude"] = parsed_coordinates[1] if parsed_coordinates else None

    if photo and photo.filename:
        extension = Path(secure_filename(photo.filename)).suffix.lower()
        museum["image"] = save_uploaded_image(photo, "museum", f"{museum_id}{extension}")

    if location_map and location_map.filename:
        map_extension = Path(secure_filename(location_map.filename)).suffix.lower()
        museum["map_image"] = save_uploaded_image(location_map, "maps", f"{museum_id}{map_extension}")

    save_data(data)
    return jsonify({"success": True, "museum": museum})


@app.route("/api/admin/museums/<int:museum_id>", methods=["DELETE"])
def admin_delete_museum(museum_id):
    data = load_data()
    museum = find_museum(data, museum_id)
    if not museum:
        return jsonify({"error": "Музей не найден."}), 404

    data["museums"] = [item for item in data.get("museums", []) if item.get("id") != museum_id]
    data["artifacts"] = [item for item in data.get("artifacts", []) if item.get("museum_id") != museum_id]
    save_data(data)
    return jsonify({"success": True})


@app.route("/api/admin/artifacts", methods=["POST"])
def admin_create_artifact():
    name = str(request.form.get("name", "")).strip()
    museum_id = request.form.get("museum_id")
    difficulty = str(request.form.get("difficulty", "")).strip()
    map_x = request.form.get("map_x")
    map_y = request.form.get("map_y")
    image = request.files.get("image")
    if not name:
        return jsonify({"error": "Введите название артефакта."}), 400
    if not museum_id:
        return jsonify({"error": "Выберите музей."}), 400
    if not difficulty:
        return jsonify({"error": "Введите сложность."}), 400
    if not image or not allowed_file(image.filename):
        return jsonify({"error": "Загрузите изображение .jpg или .png."}), 400
    try:
        museum_id = int(museum_id)
    except ValueError:
        return jsonify({"error": "Некорректный ID музея."}), 400

    parsed_x = None
    parsed_y = None
    if map_x is not None and str(map_x).strip() != "":
        try:
            parsed_x = float(str(map_x).replace(",", "."))
        except ValueError:
            return jsonify({"error": "Некорректная координата X."}), 400
    if map_y is not None and str(map_y).strip() != "":
        try:
            parsed_y = float(str(map_y).replace(",", "."))
        except ValueError:
            return jsonify({"error": "Некорректная координата Y."}), 400
    if parsed_x is not None and not 0 <= parsed_x <= 100:
        return jsonify({"error": "Координата X должна быть в диапазоне 0..100."}), 400
    if parsed_y is not None and not 0 <= parsed_y <= 100:
        return jsonify({"error": "Координата Y должна быть в диапазоне 0..100."}), 400
    data = load_data()
    if not any(museum["id"] == museum_id for museum in data["museums"]):
        return jsonify({"error": "Музей не найден."}), 400
    artifact_id = len(data["artifacts"]) + 1
    extension = Path(secure_filename(image.filename)).suffix.lower()
    filename = f"{museum_id}_{artifact_id}{extension}"
    target_dir = BASE_DIR / "static" / "source" / "artefacts"
    target_dir.mkdir(parents=True, exist_ok=True)
    image.save(target_dir / filename)
    image_path = f"source/artefacts/{filename}"
    artifact = {
        "id": artifact_id,
        "name": name,
        "museum_id": museum_id,
        "difficulty": difficulty,
        "map_x": parsed_x,
        "map_y": parsed_y,
        "image": image_path,
    }
    data["artifacts"].append(artifact)
    for museum in data["museums"]:
        if museum["id"] == museum_id:
            museum.setdefault("artifacts", []).append(artifact_id)
            break
    save_data(data)
    return jsonify({"success": True, "artifact": artifact})


@app.route("/api/profile/avatar", methods=["POST"])
def upload_avatar():
    # Получаем файл и никнейм из формы (или query, если потребуется)
    avatar = request.files.get("avatar")
    nickname = request.form.get("nickname") or request.args.get("nickname")
    if not avatar or not allowed_file(avatar.filename):
        return jsonify({"error": "Загрузите изображение .jpg или .png."}), 400
    if not nickname:
        # Можно доработать: брать ник из сессии, если будет авторизация
        return jsonify({"error": "Не передан никнейм пользователя."}), 400
    users = load_users()
    user = next((u for u in users if u["nickname"] == nickname), None)
    if not user:
        return jsonify({"error": "Пользователь не найден."}), 404
    ext = Path(secure_filename(avatar.filename)).suffix.lower()
    filename = f"{nickname}{ext}"
    rel_path = save_uploaded_image(avatar, "avatar", filename)
    # Сохраняем путь к аватару в профиле пользователя
    user["profile"]["avatar"] = rel_path
    save_users(users)
    return jsonify({"success": True, "avatar": rel_path})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
